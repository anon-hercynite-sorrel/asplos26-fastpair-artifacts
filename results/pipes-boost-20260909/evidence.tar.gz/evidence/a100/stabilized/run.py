#!/usr/bin/env python3
"""A100 within-process boost settling; public binary/source remains unchanged."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import statistics as st
import subprocess
import time

root = Path.home() / 'fastpair-boost'
os.chdir(root)
out = root / 'stabilized'
out.mkdir(exist_ok=False)
assert (root / 'chip.txt').read_text().strip() == 'a100'
env = {k: v for k, v in os.environ.items() if not k.startswith('ONPAIR_')}
env.update(PATH=str(Path.home()/'.cargo/bin')+':'+str(Path.home()/'.local/bin')+':/usr/local/cuda/bin:'+os.environ['PATH'], ONPAIR_FAST='1')
bench = str(root / 'harness/target/release/onpair-chunk-bench')
ncu = shutil.which('ncu', path=env['PATH'])
assert ncu
PAYLOAD = 999999899
DEFAULT = 'onpair_dw_k6_t256_b4'
monitor = None
rc = 1


def command(args, stem, extra=None):
    print('COMMAND', stem, time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), flush=True)
    with (out / (stem+'.stdout')).open('w') as a, (out / (stem+'.stderr')).open('w') as b:
        subprocess.run(args, stdout=a, stderr=b, env=dict(env, **(extra or {})), check=True)


def timing(stem, names, seed=None):
    command([bench, 'gpu-decode-vortex', '--vortex', str(root/'windows12.vortex'), '--column', 'line',
             '--gpu-iters', '2100', '--gpu-validate', '--gpu-kernels', ','.join(names)], stem,
            {'ONPAIR_SHUFFLE_SEED': str(seed)} if seed is not None else None)
    (out/(stem+'.stdout')).rename(out/(stem+'.json'))
    g = json.loads((out/(stem+'.json')).read_text())['gpu']
    assert g['decoded_bytes']==PAYLOAD and g['total_tokens']==99090926 and g['chunks']==1 and g['verified'] and g['validated']
    assert abs(g['frac_le8']-.37251443)<1e-6
    assert len(g['kernels'])==len(names) and {k['kernel'] for k in g['kernels']}==set(names)
    for k in g['kernels']:
        assert k['applicable'] and k['verified'] and len(k['decode_ns_iters'])==2100 and min(k['decode_ns_iters'])>0
    return {k['kernel']: k['decode_ns_iters'][2000:] for k in g['kernels']}


try:
    assert subprocess.check_output(['git', '-C', 'harness', 'rev-parse', 'HEAD'], text=True).strip()=='f6d81878715bf322a0917ada32bcf40adffbd3ef'
    status=subprocess.check_output(['git','-C','harness','status','--porcelain'],text=True)
    assert all(line=='?? vortex-cuda/kernels/gen/' for line in status.splitlines()),status
    assert hashlib.sha256((root/'windows12.vortex').read_bytes()).hexdigest()=='067f1bc2a8df043e0b475eda6b2238cf76c93f497d3ca2b001e3a301e85cd5e6'
    for name in ('source-revision.txt','source-status.txt','input-binary.sha256','capture-metrics.txt','missing-metrics.json','selection.json'):
        shutil.copyfile(root/'boost'/name, out/name)
    recorded=(out/'input-binary.sha256').read_text()
    assert hashlib.sha256(Path(bench).read_bytes()).hexdigest() in recorded
    shutil.copyfile(__file__,out/'run.py')
    old=json.loads((root/'boost/selected.json').read_text())
    sweep=json.loads((root/'boost/sweep.json').read_text())['gpu']['kernels']
    ranked=sorted(sweep,key=lambda k:(min(k['decode_ns_iters']),st.median(k['decode_ns_iters']),k['kernel']))
    shortlist=list(dict.fromkeys([k['kernel'] for k in ranked[:3]]+[old['archived_winner'],DEFAULT]))
    (out/'screening-provenance.json').write_text(json.dumps({'source':'../boost/sweep.json','sha256':hashlib.sha256((root/'boost/sweep.json').read_bytes()).hexdigest(),'shortlist':shortlist},indent=2)+'\n')
    command(['sudo','nvidia-smi','-rgc'],'reset-gpu-clocks')
    command(['nvidia-smi','-q'],'nvidia-before')
    command([ncu,'--version'],'ncu-version')
    clocks=(out/'clocks.csv').open('w')
    monitor=subprocess.Popen(['nvidia-smi','--query-gpu=timestamp,clocks.sm,clocks.mem,pstate,power.draw,temperature.gpu,utilization.gpu','--format=csv','--loop-ms=100'],stdout=clocks,stderr=subprocess.STDOUT)
    pooled={name:[] for name in shortlist}
    for i in range(2):
        rows=timing('confirmation-'+str(i),shortlist,20260920+i)
        for name in shortlist:pooled[name]+=rows[name]
    winner=min(shortlist,key=lambda n:(min(pooled[n]),st.median(pooled[n]),n))
    selected={'winner':winner,'recommended':DEFAULT,'archived_winner':old['archived_winner'],'confirmation_candidates':shortlist,
              'discarded_per_kernel_per_process':2000,'retained_per_kernel_per_round':100,
              'selection_rule':'561-candidate prior full screen; top3 + archived winner + recommended independently confirmed twice; discard first2000 timings per kernel, minimize time across retained200, then median/name tie-break.',
              'confirmed':{n:{'n':len(t),'min_GBps':PAYLOAD/min(t),'median_GBps':PAYLOAD/st.median(t)} for n,t in pooled.items()}}
    (out/'selected.json').write_text(json.dumps(selected,indent=2)+'\n')
    print('WINNER',winner,selected['confirmed'][winner],flush=True)
    metrics=(out/'capture-metrics.txt').read_text().strip()
    for name in dict.fromkeys((winner,DEFAULT)):
        timing(name+'-before',[name])
        command(['sudo','env','TMPDIR='+str(root/'ncu-tmp'),'ONPAIR_FAST=1',ncu,'--replay-mode','application','--app-replay-match','grid',
                 '--clock-control','none','--cache-control','none','--kernel-name-base','function','--kernel-name',name,
                 '--launch-skip','2003','--launch-count','4','--metrics',metrics,'--export',str(out/name),'--log-file',str(out/(name+'.ncu.log')),
                 bench,'gpu-decode-vortex','--vortex',str(root/'windows12.vortex'),'--column','line','--gpu-iters','2100','--gpu-validate','--gpu-kernels',name],name+'.profile')
        command([ncu,'--import',str(out/(name+'.ncu-rep')),'--page','raw','--csv','--print-units','base'],name+'.raw')
        (out/(name+'.raw.stdout')).rename(out/(name+'.raw.csv'))
        timing(name+'-after',[name])
        print('PROFILE_DONE',name,flush=True)
    command(['nvidia-smi','-q'],'nvidia-after')
    (out/'CAPTURE_COMPLETE').write_text('Complete; independent settled-clock/timing validation required.\n')
    rc=0
finally:
    if monitor:
        monitor.terminate();monitor.wait(timeout=10);clocks.close()
    (out/'exit-code').write_text(str(rc)+'\n')
    print('EXIT',rc,flush=True)
