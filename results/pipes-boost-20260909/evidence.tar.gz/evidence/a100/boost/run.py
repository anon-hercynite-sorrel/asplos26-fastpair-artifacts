#!/usr/bin/env python3
import os,sys,json,subprocess,hashlib,statistics,time,random,csv,io
from pathlib import Path
root=Path.home()/'fastpair-boost';os.chdir(root)
out=root/'boost';out.mkdir(exist_ok=False)
chip=(root/'chip.txt').read_text().strip()
env=dict(os.environ,PATH=str(Path.home()/'.cargo/bin')+':'+str(Path.home()/'.local/bin')+':/usr/local/cuda/bin:'+os.environ['PATH'],ONPAIR_FAST='1')
for key in ('ONPAIR_SHUFFLE_SEED','ONPAIR_L2_PERSIST','ONPAIR_CARVEOUT','ONPAIR_REVIEW_STAGING_BLOCKS_PER_SM'):env.pop(key,None)
bench=str(root/'harness/target/release/onpair-chunk-bench')
import shutil
ncu=shutil.which('ncu',path=env['PATH']);assert ncu
payload=999999899;tokens=99090926;default='onpair_dw_k6_t256_b4'
candidates=(root/'candidates.txt').read_text().splitlines();assert len(candidates)==561
selection=json.loads((root/'selection.json').read_text())[chip]
monitor=None;rc=1

def cmd(args,stem,extra=None,check=True):
 with (out/(stem+'.stdout')).open('w') as a,(out/(stem+'.stderr')).open('w') as b:
  q=subprocess.run(args,stdout=a,stderr=b,env=env if extra is None else dict(env,**extra),text=True)
 if check and q.returncode:raise RuntimeError(f'{stem}: exit {q.returncode}')
 return q.returncode

def timing(stem,names,iters=100,seed=None):
 args=[bench,'gpu-decode-vortex','--vortex',str(root/'windows12.vortex'),'--column','line','--gpu-iters',str(iters),'--gpu-validate','--gpu-kernels',','.join(names)]
 cmd(args,stem,extra={'ONPAIR_SHUFFLE_SEED':str(seed)} if seed else None)
 p=out/(stem+'.stdout');p.rename(out/(stem+'.json'));g=json.loads((out/(stem+'.json')).read_text())['gpu']
 assert g['decoded_bytes']==payload and g['total_tokens']==tokens and g['chunks']==1 and g['verified'] and g['validated'] and abs(g['frac_le8']-.37251443)<1e-6
 assert {k['kernel'] for k in g['kernels']}==set(names)
 for k in g['kernels']:
  assert k['applicable'] and k['verified'] and len(k['decode_ns_iters'])==iters and min(k['decode_ns_iters'])>0,k['kernel']
 return g

try:
 print('START',chip,time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),flush=True)
 revision=subprocess.check_output(['git','-C','harness','rev-parse','HEAD'],text=True).strip();assert revision=='f6d81878715bf322a0917ada32bcf40adffbd3ef'
 status=subprocess.check_output(['git','-C','harness','status','--porcelain'],text=True)
 (out/'source-status.txt').write_text(status)
 assert all(line=='?? vortex-cuda/kernels/gen/' for line in status.splitlines()),status
 assert hashlib.sha256((root/'windows12.vortex').read_bytes()).hexdigest()=='067f1bc2a8df043e0b475eda6b2238cf76c93f497d3ca2b001e3a301e85cd5e6'
 for name in ('chip.txt','candidates.txt','selection.json','capture-metrics.txt','missing-metrics.json'):shutil.copyfile(root/name,out/name)
 (out/'input-binary.sha256').write_text(''.join(hashlib.sha256(Path(p).read_bytes()).hexdigest()+'  '+p+'\n' for p in (str(root/'windows12.vortex'),bench)))
 (out/'source-revision.txt').write_text(revision+'\n')
 shutil.copyfile(__file__,out/'run.py')
 cmd(['nvidia-smi','-q'],'nvidia-before')
 cmd(['sudo','nvidia-smi','-pm','1'],'persistence',check=False)
 cmd(['sudo','nvidia-smi','-rgc'],'reset-gpu-clocks')
 cmd(['sudo','nvidia-smi','-rac'],'reset-application-clocks',check=False)
 cmd(['nvidia-smi','-q'],'nvidia-unlocked')
 cmd([ncu,'--version'],'ncu-version');cmd(['nvcc','--version'],'nvcc-version');cmd(['rustc','--version'],'rust-version')
 subprocess.run(['sudo','mkdir','-p',str(root/'ncu-tmp')],check=True)
 subprocess.run(['sudo','chmod','700',str(root/'ncu-tmp')],check=True)
 clocks=(out/'clocks.csv').open('w')
 monitor=subprocess.Popen(['nvidia-smi','--query-gpu=timestamp,clocks.sm,clocks.mem,pstate,power.draw,temperature.gpu,utilization.gpu','--format=csv','--loop-ms=100'],stdout=clocks,stderr=subprocess.STDOUT)
 timing('warmup',[selection['archived_winner']],iters=2000)
 print('SWEEP_START',len(candidates),flush=True)
 sweep=timing('sweep',candidates,seed=20260909)
 ranked=sorted(sweep['kernels'],key=lambda k:(min(k['decode_ns_iters']),statistics.median(k['decode_ns_iters']),k['kernel']))
 confirm=list(dict.fromkeys([k['kernel'] for k in ranked[:3]]+[selection['archived_winner'],default]))
 pooled={name:[] for name in confirm}
 print('SWEEP_DONE',[(k['kernel'],payload/min(k['decode_ns_iters'])) for k in ranked[:5]],flush=True)
 for rnd in range(2):
  g=timing('confirmation-'+str(rnd),confirm,seed=20260910+rnd)
  for k in g['kernels']:pooled[k['kernel']]+=k['decode_ns_iters']
 winner=min(confirm,key=lambda name:(min(pooled[name]),statistics.median(pooled[name]),name))
 selected={'winner':winner,'recommended':default,'archived_winner':selection['archived_winner'],'full_sweep_count':len(candidates),'confirmation_candidates':confirm,'confirmed':{name:{'n':len(ts),'min_GBps':payload/min(ts),'median_GBps':payload/statistics.median(ts)} for name,ts in pooled.items()},'selection_rule':'minimum CUDA-event time across two confirmation rounds (200 samples), shortlist top3 fresh full-sweep + archived winner + recommended; median then name breaks exact ties','clock_policy':'GPU clocks reset; application clocks reset if supported; unlocked boost; NCU clock-control none'}
 (out/'selected.json').write_text(json.dumps(selected,indent=2)+'\n')
 print('WINNER',winner,selected['confirmed'][winner],flush=True)
 metrics=(root/'capture-metrics.txt').read_text().strip()
 for name in dict.fromkeys((winner,default)):
  timing(name+'-before',[name])
  stem=name+'.profile'
  cmd(['sudo','env','TMPDIR='+str(root/'ncu-tmp'),'ONPAIR_FAST=1',ncu,'--replay-mode','application','--app-replay-match','grid','--clock-control','none','--cache-control','none','--kernel-name-base','function','--kernel-name',name,'--launch-skip','3','--launch-count','4','--metrics',metrics,'--export',str(out/name),'--log-file',str(out/(name+'.ncu.log')),bench,'gpu-decode-vortex','--vortex',str(root/'windows12.vortex'),'--column','line','--gpu-iters','8','--gpu-validate','--gpu-kernels',name],stem)
  cmd([ncu,'--import',str(out/(name+'.ncu-rep')),'--page','raw','--csv','--print-units','base'],name+'.raw')
  (out/(name+'.raw.stdout')).rename(out/(name+'.raw.csv'))
  timing(name+'-after',[name])
  print('PROFILE_DONE',name,flush=True)
 cmd(['nvidia-smi','-q'],'nvidia-after')
 (out/'CAPTURE_COMPLETE').write_text('Complete; independent local raw-metric/geometry/clock validation still required.\n')
 rc=0
finally:
 if monitor:monitor.terminate();monitor.wait(timeout=10);clocks.close()
 (out/'exit-code').write_text(str(rc)+'\n')
 print('EXIT',rc,flush=True)
